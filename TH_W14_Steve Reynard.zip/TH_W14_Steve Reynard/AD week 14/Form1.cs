﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SqlServer.Server;
using MySql.Data.MySqlClient;


namespace AD_week_14
{
    public partial class premier : Form
    {
        MySqlConnection sqlConnection;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtTeam = new DataTable();
        DataTable dtAway = new DataTable();
        DataTable players = new DataTable();
        DataTable dt = new DataTable();
        DataTable dmatch = new DataTable();
        string query;
        string idhome;
        string idaway;
        string idteam;
        int index = 0;

        public premier()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tbMatchID.Enabled = false;
            sqlConnection = new MySqlConnection("server=localhost;uid=root;pwd=root;database=premier_league");
            dtTeam = new DataTable();
            dtAway = new DataTable();
            query = "select team_id, team_name from team t";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeam);
            sqlDataAdapter.Fill(dtAway);
            cbTHome.DataSource = dtTeam;
            cbTHome.DisplayMember = "team_name";
            cbTHome.ValueMember = "team_id";
            cbTHome.SelectedIndex = -1;
            cbTAway.DataSource = dtAway;
            cbTAway.DisplayMember = "team_name";
            cbTAway.ValueMember = "team_id";
            cbTAway.SelectedIndex = -1;
            dt.Columns.Add("Minute");
            dt.Columns.Add("Team");
            dt.Columns.Add("Player");
            dt.Columns.Add("Type");

            dmatch = new DataTable();
            dmatch.Columns.Add("match_id");
            dmatch.Columns.Add("minute");
            dmatch.Columns.Add("team_id");
            dmatch.Columns.Add("player_id");
            dmatch.Columns.Add("type");
            dmatch.Columns.Add("delete");

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            dt.Rows.Add(tbMinute.Text, cbTeam.Text, cbPlayer.Text, cbType.Text);
            dgv.DataSource = dt;
            dmatch.Rows.Add(tbMatchID.Text, tbMinute.Text, idteam, cbPlayer.SelectedValue, cbType.Text, 0);
        }

        private void dTime_ValueChanged(object sender, EventArgs e)
        {
           
            string year = dTime.Value.Year.ToString();
            query = $"select count(match_id) from `match` where match_id like '{year}%';";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            DataTable dtCount = new DataTable();
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtCount);

            if (Convert.ToInt32(dtCount.Rows[0][0])<10)
            {
                tbMatchID.Text = $"{year}00{(Convert.ToInt32(dtCount.Rows[0][0])+1).ToString()}";

            }
            else if (Convert.ToInt32(dtCount.Rows[0][0]) >= 10 && Convert.ToInt32(dtCount.Rows[0][0]) < 100)
            {
                tbMatchID.Text = $"{year}0{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
            }
            else if (Convert.ToInt32(dtCount.Rows[0][0]) >= 100)
            {
                tbMatchID.Text = $"{year}{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
            }
        }

        private void cbTHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTHome.SelectedIndex == -1 && cbTAway.SelectedIndex ==-1)
            {

            }
            else
            {
                if (cbTAway.Text == cbTHome.Text)
                {
                    MessageBox.Show("Team Home tidk boleh sama");
                    cbTAway.SelectedIndex = -1;
                    cbTHome.SelectedIndex = -1;
                }
                else
                {
                    cbTeam.Items.Clear();
                    idhome =  Convert.ToString(cbTHome.SelectedValue);
                    idaway =  Convert.ToString(cbTAway.SelectedValue);
                    cbTeam.Items.Add(cbTHome.Text);
                    cbTeam.Items.Add(cbTAway.Text);

                }
            }
        }

        private void cbTAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTHome.SelectedIndex == -1 && cbTAway.SelectedIndex == -1)
            {

            }
            else
            {
                if (cbTAway.Text == cbTHome.Text)
                {
                    MessageBox.Show("Team Home tidak boleh sama");
                    cbTAway.SelectedIndex = -1;
                    cbTHome.SelectedIndex = -1;
                }
                else
                {
                    cbTeam.Items.Clear();
                    idhome = Convert.ToString(cbTHome.SelectedValue);
                    idaway = Convert.ToString(cbTAway.SelectedValue);
                    cbTeam.Items.Add(cbTHome.Text);
                    cbTeam.Items.Add(cbTAway.Text);

                }
            }
        }

        private void cbTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            players = new DataTable();
            if (cbTeam.SelectedIndex == 0)
            {
                idteam = idhome;
            }
            if (cbTeam.SelectedIndex == 1)
            {
                idteam = idaway;
            }
            query = $"select player_id, player_name from player where team_id like '%{idteam}%'";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(players);
            cbPlayer.DataSource = players;
            cbPlayer.DisplayMember = "player_name";
            cbPlayer.ValueMember = "player_id";

        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            dt.Rows.RemoveAt(index);
            dgv.DataSource = dt;
            dmatch.Rows.RemoveAt(index);
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            bool tanggalBenar = false;
            if (dTime.Value.Year == 2016 && dTime.Value.Month == 2 && dTime.Value.Day >= 14)
            {


                tanggalBenar = true;
            }
            else if (dTime.Value.Year == 2016 && dTime.Value.Month > 2)
            {
                tanggalBenar = true;
            }
            else if (dTime.Value.Year > 2016)
            {
                tanggalBenar = true;
            }
            else
            {

                tanggalBenar = false;
            }

            if (tanggalBenar)
            {
                try
                {
                    sqlConnection.Open();
                    for (int i = 0; i < dmatch.Rows.Count; i++)
                    {
                        query = $"insert into dmatch values ({dmatch.Rows[i][0]}, {dmatch.Rows[i][1]}, '{dmatch.Rows[i][2]}', '{dmatch.Rows[i][3]}', '{dmatch.Rows[i][4]}', {dmatch.Rows[i][5]});";
                        sqlCommand = new MySqlCommand(query, sqlConnection);
                        sqlCommand.ExecuteNonQuery();
                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                int scorehome = 0;
                int scoreaway = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i][1].ToString() == cbTHome.Text)
                    {
                        if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                        {
                            scorehome++;
                        }
                        else if (dt.Rows[i][3].ToString() == "GW")
                        {
                            scoreaway++;
                        }
                    }
                    else
                    {
                        if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                        {
                            scoreaway++;
                        }
                        else if (dt.Rows[i][3].ToString() == "GW")
                        {
                            scorehome++;
                        }
                    }
                }
                try
                {
                    query = $"insert into `match` values ('{tbMatchID.Text}', '{dTime.Value.ToString("yyyy-MM-dd")}', '{idhome}', '{idaway}', {scorehome}, {scoreaway}, 'M002', 0);";
                    sqlCommand = new MySqlCommand(query, sqlConnection);
                    sqlCommand.ExecuteNonQuery();
                    sqlConnection.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Tanggal tidak valid");
            }
        }

            
           
    }
}
